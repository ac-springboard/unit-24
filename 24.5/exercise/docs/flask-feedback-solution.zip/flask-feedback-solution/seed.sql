DROP DATABASE IF EXISTS feedback_exercise;

CREATE DATABASE feedback_exercise;